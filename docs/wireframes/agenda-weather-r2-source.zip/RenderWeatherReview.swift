import AppKit
import CoreGraphics
import Foundation
import ImageIO
import Metal
import UniformTypeIdentifiers

@main
struct RenderWeatherReview {
    enum ReviewError: Error { case arguments, noDevice, noTexture, badFrame, noCanvas, writeFailed }
    static let fps = 24
    static let framesPerWeather = 96
    static let space = CGColorSpace(name:CGColorSpace.sRGB)!
    static let format = CGBitmapInfo.byteOrder32Little.union(.init(rawValue:CGImageAlphaInfo.noneSkipFirst.rawValue))

    @MainActor static func main() throws {
        let args = CommandLine.arguments
        guard args.count == 3, ["stills","movie"].contains(args[2]) else { throw ReviewError.arguments }
        let out = URL(fileURLWithPath:args[1],isDirectory:true)
        let _ = NSApplication.shared
        NSApp.setActivationPolicy(.prohibited)
        NSApp.appearance = NSAppearance(named:.aqua)
        guard let gpu = MTLCreateSystemDefaultDevice() else { throw ReviewError.noDevice }
        let library = try gpu.makeLibrary(URL:out.appendingPathComponent("Sky.metallib"))
        let renderer = try VolumetricSky(device:gpu,library:library)
        let w = reviewWidth, h = reviewHeight, row = w*4
        let desc = MTLTextureDescriptor.texture2DDescriptor(pixelFormat:VolumetricSky.pixelFormat,width:w,height:h,mipmapped:false)
        desc.storageMode = .shared; desc.usage = [.renderTarget]
        guard let target = gpu.makeTexture(descriptor:desc) else { throw ReviewError.noTexture }
        let pass = MTLRenderPassDescriptor()
        pass.colorAttachments[0].texture = target
        pass.colorAttachments[0].loadAction = .dontCare; pass.colorAttachments[0].storeAction = .store
        let time = SkyTime(minute:610,on:SchoolClock.date(2026,11,19,minute:610))
        for (name,weather) in [("sunny",Weather.sunny),("rain",Weather.moderateRain)] {
            guard let ui = ReviewLayer.ui(weather:weather) else { throw ReviewError.noCanvas }
            let state = VolumetricSkyState(time:time,style:weather.style,festival:.none)
            let frames: [Int] = args[2] == "movie" ? Array(0..<framesPerWeather) : [0,54,90]
            for frame in frames {
                try autoreleasepool {
                    let elapsed = 8.0 + Double(frame)/Double(fps)
                    let u = state.uniforms(width:w,height:h,steps:96,elapsed:elapsed,moving:true)
                    guard let buf = renderer.queue.makeCommandBuffer(),renderer.encode(u,in:buf,to:pass) else { throw ReviewError.badFrame }
                    buf.commit(); buf.waitUntilCompleted()
                    guard buf.status == .completed else { throw buf.error ?? ReviewError.badFrame }
                    var raw = Data(count:h*row)
                    let precipitation = ReviewLayer.precipitation(weather:weather,time:time,elapsed:elapsed)
                    if weather == .moderateRain && precipitation == nil { throw ReviewError.noCanvas }
                    try raw.withUnsafeMutableBytes { px in
                        guard let addr = px.baseAddress,
                              let c = CGContext(data:addr,width:w,height:h,bitsPerComponent:8,bytesPerRow:row,space:space,bitmapInfo:format.rawValue)
                        else { throw ReviewError.badFrame }
                        target.getBytes(addr,bytesPerRow:row,from:MTLRegionMake2D(0,0,w,h),mipmapLevel:0)
                        if let overlay = precipitation { c.draw(overlay,in:ReviewLayer.bounds) }
                        c.draw(ui,in:ReviewLayer.bounds); c.flush()
                    }
                    if args[2] == "movie" {
                        try FileHandle.standardOutput.write(contentsOf:raw)
                    } else {
                        let url = out.appendingPathComponent("\(name)-\(frame).png")
                        guard !FileManager.default.fileExists(atPath:url.path),
                              let provider = CGDataProvider(data:raw as CFData),
                              let img = CGImage(width:w,height:h,bitsPerComponent:8,bitsPerPixel:32,bytesPerRow:row,space:space,bitmapInfo:format,provider:provider,decode:nil,shouldInterpolate:false,intent:.defaultIntent),
                              let writer = CGImageDestinationCreateWithURL(url as CFURL,UTType.png.identifier as CFString,1,nil)
                        else { throw ReviewError.writeFailed }
                        CGImageDestinationAddImage(writer,img,nil)
                        guard CGImageDestinationFinalize(writer) else { throw ReviewError.writeFailed }
                    }
                }
            }
        }
    }
}

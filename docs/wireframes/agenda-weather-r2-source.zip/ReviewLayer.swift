import AppKit
import SwiftUI

// This standalone review artboard is not part of the app. It redraws the synthetic
// R1 agenda, so the two weather conditions use identical dates, rows and typography.
let reviewWidth = 1180, reviewHeight = 820
extension SkyColor { var color: Color { Color(red: red, green: green, blue: blue) } }

enum ReviewLayer {
    static let bounds = CGRect(x: 0, y: 0, width: reviewWidth, height: reviewHeight)
    static let ink = Color.black.opacity(0.91)
    static let muted = Color.black.opacity(0.68)
    static let rule = Color.black.opacity(0.13)

    @MainActor static func image<Content: View>(_ content: Content) -> CGImage? {
        let view = content.frame(width: CGFloat(reviewWidth), height: CGFloat(reviewHeight))
            .environment(\.colorScheme, .light).environment(\.locale, Locale(identifier: "zh_CN"))
        let renderer = ImageRenderer(content: view)
        renderer.scale = 1
        renderer.proposedSize = ProposedViewSize(width: CGFloat(reviewWidth), height: CGFloat(reviewHeight))
        renderer.isOpaque = false
        return renderer.cgImage
    }

    @MainActor static func ui(weather: Weather) -> CGImage? {
        image(Canvas { c, _ in
            func text(_ s: String, _ x: Double, _ y: Double, _ n: Double, _ weight: Font.Weight = .regular,
                      _ color: Color = ink, digits: Bool = false) {
                var t = Text(verbatim: s).font(.system(size: n, weight: weight)).foregroundColor(color)
                if digits { t = t.monospacedDigit() }
                c.draw(t, at: CGPoint(x:x, y:y), anchor: .topLeading)
            }
            func icon(_ s: String, _ x: Double, _ y: Double, _ n: Double, _ color: Color) {
                var symbol = c.resolve(Image(systemName: s))
                symbol.shading = .color(color)
                let intrinsic = symbol.size
                let scale = n / max(1, intrinsic.width, intrinsic.height)
                let w = intrinsic.width * scale, h = intrinsic.height * scale
                c.draw(symbol, in: CGRect(x:x + (n-w)/2, y:y + (n-h)/2, width:w, height:h))
            }
            func line(_ x: Double, _ y: Double, _ endX: Double, _ endY: Double, _ color: Color, _ width: Double = 1) {
                var p = Path(); p.move(to: CGPoint(x:x,y:y)); p.addLine(to: CGPoint(x:endX,y:endY))
                c.stroke(p, with:.color(color), lineWidth: width)
            }
            func rounded(_ x: Double,_ y: Double,_ w: Double,_ h: Double,_ r: Double,_ color: Color) {
                c.fill(Path(roundedRect:CGRect(x:x,y:y,width:w,height:h),cornerRadius:r), with:.color(color))
            }

            // The sky is a full-viewport layer, not a banner. Only text and controls
            // receive a neutral surface. The next-class block is fully opaque.
            c.fill(Path(CGRect(x:0,y:0,width:236,height:820)), with:.color(.white.opacity(0.90)))
            line(236,0,236,820,rule)
            let wash = Gradient(stops: [
                .init(color: .white.opacity(0.92),location:0), .init(color:.white.opacity(0.86),location:0.43),
                .init(color:.white.opacity(0.14),location:0.72), .init(color:.white.opacity(0),location:1)
            ])
            c.drawLayer { layer in
                let header = Path(CGRect(x:237,y:0,width:943,height:205))
                layer.fill(header,with:.linearGradient(wash,startPoint:CGPoint(x:237,y:0),endPoint:CGPoint(x:980,y:0)))
                layer.blendMode = .destinationIn
                layer.fill(header,with:.linearGradient(Gradient(stops:[
                    .init(color:.white,location:0), .init(color:.white,location:0.62), .init(color:.clear,location:1)
                ]),startPoint:.zero,endPoint:CGPoint(x:0,y:205)))
            }
            rounded(247,151,918,457,20,.white)

            text("Xiaobao",24,25,32,.bold)
            text("校园",24,101,16,.semibold,muted)
            text("学习",24,295,16,.semibold,muted)
            text("记录",24,565,16,.semibold,muted)
            func nav(_ title: String,_ glyph: String,_ cy: Double, selected: Bool = false) {
                if selected { rounded(12,cy-20,216,40,9,.blue.opacity(0.13)) }
                icon(glyph,26,cy-11,22,selected ? .blue : muted)
                text(title,66,cy-14,20,selected ? .semibold : .regular,ink)
            }
            nav("今日","sun.horizon",153); nav("课表","rectangle.split.3x3",198)
            nav("我的日程","calendar",243,selected:true)
            nav("全部成绩","chart.bar.xaxis",342); nav("我的任务","checklist",386)
            nav("我的考试","pencil.and.list.clipboard",430); nav("我的测评","text.badge.checkmark",474)
            nav("我的资料库","folder",518); nav("我的考勤","person.badge.clock",616)
            line(24,671,211,671,rule); nav("设置","slider.horizontal.3",712); nav("完整校宝","safari",757)

            text("日程",265,25,36,.bold)
            icon("chevron.left",264,101,16,ink); text("11月19日   周四 · Day 6",307,94,23,.medium)
            icon("chevron.right",600,101,16,ink)
            rounded(1023,19,135,53,26,.white.opacity(0.86))
            icon(weather.symbol,1042,31,29,ink); icon("safari",1105,31,29,ink)
            text("接下来",303,168,18,.semibold,.blue)
            line(276,182,276,584,rule,1.2)
            line(276,219,276,279,.blue,2.2)

            func row(_ y: Double, _ clock: String, _ title: String, _ detail: String,
                     _ glyph: String, first: Bool = false) {
                let ctr = y+19
                if first {
                    c.fill(Path(ellipseIn:CGRect(x:269.6,y:ctr-6.4,width:12.8,height:12.8)),with:.color(.blue))
                } else {
                    let dot = Path(ellipseIn:CGRect(x:270,y:ctr-6,width:12,height:12))
                    c.fill(dot,with:.color(.white)); c.stroke(dot,with:.color(.black.opacity(0.32)),lineWidth:1.4)
                }
                text(clock,303,y,first ? 28 : 25,first ? .semibold : .medium,ink,digits:true)
                text(title,416,y-2,first ? 28 : 25,first ? .semibold : .medium)
                icon(glyph,417,y+37,18,muted)
                text(detail,445,y+32,20,.regular,muted)
                if first { icon("chevron.right",1133,y+13,14,.black.opacity(0.43)) }
                line(303,y+79,1146,y+79,rule,0.8)
            }
            row(201,"10:20","地球科学","地学实验室","mappin.circle",first:true)
            row(303,"11:15","世界史","文科楼 205","mappin.circle")
            row(404,"13:40","听力测验","考试 · 语音室","mappin.circle")
            row(505,"16:30","城市声景采样","任务截止 · 音乐","clock")
        })
    }

    @MainActor static func precipitation(weather: Weather, time: SkyTime, elapsed: Double) -> CGImage? {
        let style = weather.style, frame = style.frame(at:elapsed)
        guard frame.hasParticles || frame.veil > 0 else { return nil }
        let steady = style.frame()
        return image(Canvas { c,size in
            let tint = AtmosphereColors.veil(style.mood, daylight:time.daylight)
            let fog = Gradient(stops:[
                .init(color:tint.opacity(0.23*frame.veil),location:0),
                .init(color:tint.opacity(0.626*frame.veil),location:0.52),
                .init(color:tint.opacity(frame.veil),location:1)])
            c.fill(Path(CGRect(origin:.zero,size:size)), with:.linearGradient(fog,startPoint:.zero,endPoint:CGPoint(x:0,y:size.height)))
            SkyParticles.draw(frame, motion:steady, seconds:elapsed, in:c, size:size, daylight:time.daylight)
        })
    }
}

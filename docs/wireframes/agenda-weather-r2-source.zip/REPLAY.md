# 日程 R2：设计预览复现
这是离屏评审稿，不属于 iPad App 的 Target。预览使用同一张代码绘制的日程、不含真实记录、不联网。使用支持 Metal 的 Mac、Xcode Metal 工具链和 ffmpeg。两份 Swift 文件和当天仓库的代码共同构建；并未另造一套天气引擎。

在新的空目录解开这份源稿，将其绝对路径赋给 REVIEW_SOURCE，然后在本仓库的 Xiaobao-iPadOS/ 目录用 zsh 运行：

```zsh
set -e
set -o pipefail
: "${REVIEW_SOURCE:?请指定解开此源稿的目录}"
out="$(mktemp -d "${TMPDIR%/}/xiaobao-design-r2-XXXXXXXX")"
a=Sources/Native/Atmosphere
xcrun -sdk macosx metal -std=metal3.1 -O3 -c "$a/Shaders/VolumetricSky.metal" -o "$out/Sky.air"
xcrun -sdk macosx metallib "$out/Sky.air" -o "$out/Sky.metallib"
xcrun swiftc -O -warnings-as-errors Sources/Core/SchoolDay.swift Sources/Core/Atmosphere/*.swift \
  "$a/VolumetricSky.swift" "$a/VolumetricSkyState.swift" "$a/SkyParticles.swift" "$a/AtmosphereColors.swift" \
  "$REVIEW_SOURCE/ReviewLayer.swift" "$REVIEW_SOURCE/RenderWeatherReview.swift" -o "$out/weather-review"
"$out/weather-review" "$out" stills
"$out/weather-review" "$out" movie | ffmpeg -hide_banner -loglevel error -nostdin -n -f rawvideo \
  -pixel_format bgra -video_size 1180x820 -framerate 24 -i pipe:0 -an \
  -vf 'scale=out_color_matrix=bt709:out_range=tv,format=yuv420p' -c:v libx264 -profile:v high -level 4.0 \
  -preset veryfast -crf 17 -g 48 -colorspace bt709 -color_trc bt709 -color_primaries bt709 -color_range tv \
  -movflags +faststart "$out/agenda-weather-r2.mp4"
printf '预览位于 %s\n' "$out"
```
